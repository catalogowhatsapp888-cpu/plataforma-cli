#!/bin/bash
echo "🎨 Iniciando Painel (Frontend)..."
cd frontend
npm run dev
