import uuid
from sqlalchemy import Column, String, Boolean, DateTime, Text, Integer, ForeignKey, DECIMAL, ARRAY, Date, Uuid
# from sqlalchemy.dialects.postgresql import UUID # Removed for SQLite compatibility
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base

class Contact(Base):
    __tablename__ = "contacts"

    id = Column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    full_name = Column(String(255))
    phone_e164 = Column(String(20), unique=True, nullable=False)
    email = Column(String(255))
    cpf = Column(String(14))
    source = Column(String(50))  # 'sheets', 'indication', 'ads'
    type = Column(String(20), default='lead')  # 'lead', 'patient'
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    last_interaction_at = Column(DateTime(timezone=True))
    opt_in = Column(Boolean, default=False)
    # tags = Column(ARRAY(Text)) # Commenting out for simplicity in SQLite dev if needed, but we are using Postgres so it is fine.

    # Relationships
    lead_pipeline = relationship("LeadPipeline", back_populates="contact", uselist=False)
    conversations = relationship("Conversation", back_populates="contact")
    procedures = relationship("Procedure", back_populates="contact")


class LeadPipeline(Base):
    __tablename__ = "leads_pipeline"

    contact_id = Column(Uuid(as_uuid=True), ForeignKey("contacts.id"), primary_key=True)
    stage = Column(String(50), nullable=False, default='novo')
    temperature = Column(String(20), default='frio')
    score = Column(Integer, default=0)
    assigned_to = Column(Uuid(as_uuid=True), nullable=True) # Assuming User table exists later
    unread_count = Column(Integer, default=0)
    notes = Column(Text)

    contact = relationship("Contact", back_populates="lead_pipeline")


class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contact_id = Column(Uuid(as_uuid=True), ForeignKey("contacts.id"))
    status = Column(String(20), default='open')
    started_at = Column(DateTime(timezone=True), server_default=func.now())
    closed_at = Column(DateTime(timezone=True))

    contact = relationship("Contact", back_populates="conversations")
    messages = relationship("Message", back_populates="conversation")


class Message(Base):
    __tablename__ = "messages"

    id = Column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id = Column(Uuid(as_uuid=True), ForeignKey("conversations.id"))
    external_id = Column(String(100))
    direction = Column(String(10), nullable=False) # 'inbound', 'outbound'
    content = Column(Text)
    content_type = Column(String(20), default='text')
    status = Column(String(20), default='queued')
    timestamp = Column(DateTime(timezone=True), server_default=func.now())

    conversation = relationship("Conversation", back_populates="messages")


class Procedure(Base):
    __tablename__ = "procedures"

    id = Column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contact_id = Column(Uuid(as_uuid=True), ForeignKey("contacts.id"))
    external_id = Column(String(100))
    procedure_name = Column(String(255), nullable=False)
    category = Column(String(100))
    performed_at = Column(Date, nullable=False)
    value = Column(DECIMAL(10, 2))
    next_maintenance_date = Column(Date)

    contact = relationship("Contact", back_populates="procedures")
