from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import shutil
import os
from uuid import uuid4

from app.core.config import settings

from app.db.session import engine
from app.db.base import Base
from app.models import models # Importa modelos para registro

# Cria as tabelas no banco de dados (Modo Dev)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Plataforma Clínica",
    version="1.0.0",
    openapi_url="/api/v1/openapi.json"
)

# Configuração de CORS
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 📂 Servir Arquivos Estáticos (Uploads)
os.makedirs("app/static/uploads", exist_ok=True)
app.mount("/static", StaticFiles(directory="app/static"), name="static")

# 📤 Endpoint de Upload Rápido (Local)
@app.post("/api/v1/upload")
async def upload_file(file: UploadFile = File(...)):
    # Gera nome único
    ext = file.filename.split('.')[-1]
    filename = f"{uuid4()}.{ext}"
    path = f"app/static/uploads/{filename}"
    
    with open(path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    return {"url": f"http://127.0.0.1:8000/static/uploads/{filename}"}

@app.get("/")
def read_root():
    return {"message": "Plataforma Clínica API rodando", "version": "1.0.0"}

@app.get("/health")
def health_check():
    return {"status": "ok", "db": "not_connected_yet"}

from app.api.v1.api import api_router
app.include_router(api_router, prefix="/api/v1")
