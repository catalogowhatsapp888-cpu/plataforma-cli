from fastapi import APIRouter, Request, Depends
from sqlalchemy.orm import Session
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.models import Contact, Conversation, Message, LeadPipeline
from sqlalchemy.sql import func
import logging
import json

router = APIRouter()

# Configuração básica de log para o módulo
logger = logging.getLogger(__name__)

@router.post("/")
async def handle_webhook(request: Request, db: Session = Depends(get_db)):
    try:
        body_bytes = await request.body()
        payload = json.loads(body_bytes)
        
        # 1. Identificar Evento (Flexível: aceita 'type' ou 'event', Upper ou Lower)
        event = payload.get('type') or payload.get('event')
        
        # Se não for MESSAGES_UPSERT, loga warning mas tenta processar sem bloquear rigidamente
        if not event or 'MESSAGES_UPSERT' not in event.upper():
            pass 

        # 2. Extrair Dados Principais
        data = payload.get('data', {})
        key = data.get('key', {})
        content_obj = data.get('message', {})

        if not content_obj:
            return {"status": "ignored_no_content"}

        remote_jid = key.get('remoteJid', '')
        from_me = key.get('fromMe', False)
        push_name = data.get('pushName', 'Desconhecido')
        msg_id = key.get('id')

        # 3. Tratamento de Telefone (Estratégia Robusta com/sem 9º dígito)
        phone_raw = remote_jid.split('@')[0]
        
        candidates = [phone_raw, f"+{phone_raw}"]
        if phone_raw.startswith("55") or phone_raw.startswith("+55"):
            clean_p = phone_raw.replace('+', '')
            ddd = clean_p[2:4]
            rest = clean_p[4:]
            
            if len(rest) == 8: # Sem 9 -> Adiciona 9 para testar
                p_new = f"55{ddd}9{rest}"
                candidates.extend([p_new, f"+{p_new}"])
            elif len(rest) == 9 and rest.startswith('9'): # Com 9 -> Remove 9 para testar
                p_new = f"55{ddd}{rest[1:]}"
                candidates.extend([p_new, f"+{p_new}"])

        # Busca contato no BD
        contact = None
        for p in candidates:
            contact = db.query(Contact).filter(Contact.phone_e164 == p).first()
            if contact:
                break
        
        # 4. Auto-Create Contact (Se não achar, cria na hora para garantir persistência)
        if not contact:
            print(f"👤 Novo Contato Detectado: {push_name} ({phone_raw})")
            new_phone = f"+{phone_raw}" if not phone_raw.startswith('+') else phone_raw
            contact = Contact(
                full_name=push_name,
                phone_e164=new_phone,
                type='lead',
                source='whatsapp_inbound'
            )
            db.add(contact)
            db.commit()
            db.refresh(contact)

        # 5. Garantir Conversa Aberta
        conversation = db.query(Conversation).filter(
            Conversation.contact_id == contact.id,
            Conversation.status == 'open'
        ).first()

        if not conversation:
            conversation = Conversation(contact_id=contact.id)
            db.add(conversation)
            db.commit()
            db.refresh(conversation)

        # 6. Processar Conteúdo da Mensagem
        text_content = ""
        msg_type = "text"
        
        if 'conversation' in content_obj:
            text_content = content_obj['conversation']
        elif 'extendedTextMessage' in content_obj:
            text_content = content_obj['extendedTextMessage'].get('text', '')
        elif 'imageMessage' in content_obj:
            text_content = content_obj['imageMessage'].get('caption', '<Imagem>')
            msg_type = "image"
        elif 'audioMessage' in content_obj:
            text_content = "<Áudio>"
            msg_type = "audio"
        else:
            # Fallback para debug
            text_content = f"[{list(content_obj.keys())[0]}]"
            msg_type = "media"

        # 7. Evitar Duplicidade de ID
        existing = db.query(Message).filter(Message.external_id == msg_id).first()
        # ATUALIZAÇÃO INTELIGENTE DE PIPELINE
        # Buscar ou criar pipeline se não existir
        pipeline = db.query(LeadPipeline).filter(LeadPipeline.contact_id == contact.id).first()
        if not pipeline:
            pipeline = LeadPipeline(contact_id=contact.id, stage="novo", temperature="frio")
            db.add(pipeline)
        
        if not from_me: # Inbound (Cliente mandou)
            pipeline.stage = 'nao_lido'
            pipeline.unread_count = (pipeline.unread_count or 0) + 1
        else: # Outbound (Eu mandei, via celular ou outra fonte)
            pipeline.unread_count = 0
            # Se eu respondi, e ele estava em Novo ou Não Lido -> Move para Contactado
            if pipeline.stage in ['novo', 'nao_lido']:
                pipeline.stage = 'contactado'
                print(f"🔄 Lead {contact.full_name} movido para CONTACTADO (Resposta Enviada)")

        # 8. Salvar Mensagem
        new_msg = Message(
            conversation_id=conversation.id,
            external_id=msg_id,
            direction='outbound' if from_me else 'inbound',
            content=text_content,
            content_type=msg_type,
            status='received',
            timestamp=func.now()
        )
        db.add(new_msg)
        contact.last_interaction_at = func.now()
        db.commit()
        
        print(f"✅ Recebido: {contact.full_name} diz: {text_content[:30]}...")
        return {"status": "saved", "id": msg_id}

    except Exception as e:
        print(f"❌ Erro Webhook: {str(e)}")
        import traceback
        traceback.print_exc()
        return {"status": "error", "reason": str(e)}
