from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
import uuid
from uuid import UUID
from pydantic import BaseModel
from app.db.session import get_db
from sqlalchemy.sql import func
from app.models.models import Contact, LeadPipeline, Conversation, Message
from app.schemas.lead import ContactSchema

router = APIRouter()

@router.get("/", response_model=List[ContactSchema])
def list_leads(
    skip: int = 0, 
    limit: int = 100, 
    stage: str = None, 
    db: Session = Depends(get_db)
):
    """
    Lista todos os leads paginados.
    Opcional: Filtrar por estágio (ex: ?stage=novo)
    """
    query = db.query(Contact).join(LeadPipeline)
    
    if stage:
        query = query.filter(LeadPipeline.stage == stage)
        
    leads = query.offset(skip).limit(limit).all()
    return leads

@router.get("/dashboard/stats")
def get_stats(db: Session = Depends(get_db)):
    """
    Retorna números totais para o Dashboard.
    """
    total = db.query(Contact).count()
    novos = db.query(Contact).join(LeadPipeline).filter(LeadPipeline.stage == 'novo').count()
    quentes = db.query(Contact).join(LeadPipeline).filter(LeadPipeline.temperature == 'quente').count()
    
    return {
        "total_leads": total,
        "novos": novos,
        "quentes": quentes
    }

from app.schemas.lead_update import LeadStageUpdate
from uuid import UUID

@router.put("/{lead_id}/stage")
def update_lead_stage(lead_id: UUID, update: LeadStageUpdate, db: Session = Depends(get_db)):
    """
    Atualiza o estágio do lead no pipeline.
    """
    pipeline = db.query(LeadPipeline).filter(LeadPipeline.contact_id == lead_id).first()
    if not pipeline:
        raise HTTPException(status_code=404, detail="Lead pipeline not found")
    
    if update.stage:
        pipeline.stage = update.stage
    
    if update.temperature:
        pipeline.temperature = update.temperature
    
    db.commit()
    db.refresh(pipeline)
    return {"status": "success", "new_stage": pipeline.stage}

from app.schemas.message import SendMessageRequest
from app.services.evolution_service import evolution_service

@router.post("/{lead_id}/message")
def send_lead_message(lead_id: UUID, request: SendMessageRequest, db: Session = Depends(get_db)):
    """
    Envia uma mensagem de WhatsApp para o lead.
    """
    contact = db.query(Contact).filter(Contact.id == lead_id).first()
    if not contact:
        raise HTTPException(status_code=404, detail="Lead not found")
        
    result = evolution_service.send_message(
        phone=contact.phone_e164,
        text=request.message,
        media_url=request.media_url
    )
    
    # 1. Busca ou cria conversa aberta
    # Também atualiza Stage se necessário
    pipeline = db.query(LeadPipeline).filter(LeadPipeline.contact_id == lead_id).first()
    if pipeline and pipeline.stage in ['novo', 'nao_lido']:
        pipeline.stage = 'contactado'
        # Zera unread também por garantia
        pipeline.unread_count = 0 
        db.add(pipeline) # Marca para commit
    
    conversation = db.query(Conversation).filter(
        Conversation.contact_id == lead_id, 
        Conversation.status == 'open'
    ).first()
    
    if not conversation:
        conversation = Conversation(contact_id=lead_id)
        db.add(conversation)
        db.commit()
        db.refresh(conversation)
    
    # 2. Registra mensagem
    new_msg = Message(
        conversation_id=conversation.id,
        direction='outbound',
        content=request.message,
        content_type='image' if request.media_url else 'text',
        status='sent'
    )
    db.add(new_msg)
    contact.last_interaction_at = func.now()
    db.commit()

    return result

@router.get("/{lead_id}/history")
def get_lead_history(lead_id: UUID, db: Session = Depends(get_db)):
    """
    Retorna o histórico unificado (Evolution API + Banco Local).
    Prioriza Evolution API para ter o real-time do WhatsApp.
    """
    contact = db.query(Contact).filter(Contact.id == lead_id).first()
    if not contact:
        return []

    # Zera contador de não lidos ao abrir histórico
    pipeline = db.query(LeadPipeline).filter(LeadPipeline.contact_id == lead_id).first()
    if pipeline and pipeline.unread_count > 0:
        pipeline.unread_count = 0
        db.commit()
    evo_messages = evolution_service.fetch_history(contact.phone_e164)
    
    formatted_history = []
    
    # Processa mensagens da Evolution
    if evo_messages:
        for msg in evo_messages:
            if not isinstance(msg, dict):
                print(f"⚠️ Mensagem Evolution formato inválido (ignorada): {msg}")
                continue

            key = msg.get('key', {})
            content = msg.get('message', {})
            if not content: continue 

            direction = 'outbound' if key.get('fromMe') else 'inbound'
            
            text_content = ""
            msg_type = "text"
            
            # Extração de conteúdo mais robusta (Suporte a mais tipos)
            if 'conversation' in content:
                text_content = content['conversation']
            elif 'extendedTextMessage' in content:
                text_content = content['extendedTextMessage'].get('text', '')
            elif 'imageMessage' in content:
                text_content = content['imageMessage'].get('caption', '<Imagem>')
                msg_type = "image"
            elif 'audioMessage' in content:
                text_content = "<Áudio>"
                msg_type = "audio"
            elif 'videoMessage' in content:
                text_content = content['videoMessage'].get('caption', '<Vídeo>')
                msg_type = "video"
            elif 'documentMessage' in content:
                text_content = content['documentMessage'].get('title', '<Documento>')
                msg_type = "document"
            elif 'stickerMessage' in content:
                text_content = "<Figurinha>"
                msg_type = "sticker"
            else:
                # Tenta pegar qualquer texto que sobrar
                text_content = str(content) # Fallback sujo para debug
                # Tenta achar chaves com 'Message' no nome
                for k, v in content.items():
                    if 'Message' in k and isinstance(v, dict):
                         if 'caption' in v: text_content = v['caption']
                         elif 'text' in v: text_content = v['text']
            
            # Se ainda assim estiver vazio, forçar algo para vermos no log se existe msg
            if not text_content:
                text_content = f"[Conteúdo não identificado: {list(content.keys())}]"
            
            ts = msg.get('messageTimestamp')
            timestamp_iso = ""
            if ts:
                from datetime import datetime
                dt = datetime.fromtimestamp(int(ts))
                timestamp_iso = dt.isoformat()

            if text_content:
                formatted_history.append({
                    "id": key.get('id', 'evo-'+str(uuid.uuid4())),
                    "direction": direction,
                    "content": text_content,
                    "content_type": msg_type,
                    "timestamp": timestamp_iso,
                    "source": "evolution"
                })

    # 2. Busca do Banco Local (Sempre busca!)
    local_history = db.query(Message).join(Conversation).filter(Conversation.contact_id == lead_id).all()
    
    for l_msg in local_history:
        formatted_history.append({
            "id": str(l_msg.id),
            "direction": l_msg.direction,
            "content": l_msg.content,
            "content_type": l_msg.content_type,
            "timestamp": l_msg.timestamp.isoformat() if l_msg.timestamp else "",
            "source": "local"
        })

    # 3. Remover duplicatas (Opcional, mas difícil sem ID externo consistente)
    # Por enquanto vamos mostrar tudo ordenado. Se duplicar, paciência, melhor que sumir.
    
    # Ordenar por timestamp
    formatted_history.sort(key=lambda x: x['timestamp'] or "")
    
    return formatted_history

# Endpoint para Atualizar Lead (Editar)
class LeadUpdate(BaseModel):
    full_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None

@router.put("/{lead_id}")
def update_lead(lead_id: UUID, lead_data: LeadUpdate, db: Session = Depends(get_db)):
    contact = db.query(Contact).filter(Contact.id == lead_id).first()
    if not contact:
        raise HTTPException(status_code=404, detail="Lead not found")
    
    if lead_data.full_name:
        contact.full_name = lead_data.full_name
    if lead_data.email:
        contact.email = lead_data.email
    if lead_data.phone:
        contact.phone_e164 = lead_data.phone
        
    db.commit()
    db.refresh(contact)
    return contact

# Endpoint para Criar Novo Lead (Inclusão)
class LeadCreate(BaseModel):
    full_name: str
    phone: str
    email: Optional[str] = None

def clean_phone(phone: str) -> str:
    import re
    digits = re.sub(r'\D', '', phone)
    # Se não tiver dígitos suficientes, retorna o original (vai falhar ou salvar sujo)
    if len(digits) < 8:
        return phone
        
    # Assume Brasil (+55) se não começar com 55 e tiver 10 ou 11 dígitos
    if len(digits) in [10, 11]:
        digits = '55' + digits
        
    return f"+{digits}"

@router.post("/", response_model=ContactSchema)
def create_lead(lead: LeadCreate, db: Session = Depends(get_db)):
    # Limpa telefone
    phone_clean = clean_phone(lead.phone)

    # Verifica duplicidade
    existing = db.query(Contact).filter(Contact.phone_e164 == phone_clean).first()
    if existing:
        raise HTTPException(
            status_code=400, 
            detail=f"Já existe um lead com este telefone: {existing.full_name} ({phone_clean})"
        )

    # Trata email vazio
    email_val = lead.email if lead.email and lead.email.strip() else None

    new_contact = Contact(
        full_name=lead.full_name,
        phone_e164=phone_clean,
        email=email_val,
        source="manual",
        type="lead"
    )
    db.add(new_contact)
    db.commit()
    db.refresh(new_contact)
    
    # Cria Pipeline
    pipeline = LeadPipeline(contact_id=new_contact.id, stage="novo", temperature="frio")
    db.add(pipeline)
    db.commit()
    
    return new_contact

