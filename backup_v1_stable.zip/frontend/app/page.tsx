import { Zap, Users, Flame, Calendar, RefreshCcw } from "lucide-react";
import axios from 'axios';

// Definição dos Tipos (igual ao Backend)
interface LeadPipeline {
  stage: string;
  temperature: string;
  score: number;
}

interface Contact {
  id: string;
  full_name: string;
  phone_e164: string;
  email: string | null;
  lead_pipeline: LeadPipeline | null;
  created_at: string;
}

async function getLeads() {
  try {
    // Aumentando o limite para 2000 para mostrar todos os leads importados de uma vez
    const res = await fetch('http://127.0.0.1:8000/api/v1/leads/?limit=2000', { cache: 'no-store' });
    if (!res.ok) return [];
    return res.json();
  } catch (e) {
    console.error(e);
    return [];
  }
}

async function getStats() {
  try {
    const res = await fetch('http://127.0.0.1:8000/api/v1/leads/dashboard/stats', { cache: 'no-store' });
    if (!res.ok) return { total_leads: 0, novos: 0, quentes: 0 };
    return res.json();
  } catch (e) {
    return { total_leads: 0, novos: 0, quentes: 0 };
  }
}

export default async function Dashboard() {
  const leads: Contact[] = await getLeads();
  const stats = await getStats();

  return (
    <div className="min-h-screen bg-neutral-900 text-white p-8 font-sans">
      {/* Header */}
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
            Plataforma Clínica
          </h1>
          <p className="text-neutral-400">Gestão Inteligente de Leads & Recorrência</p>
        </div>
        <div className="flex gap-4">
          <a href="/pipeline" className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-lg transition font-medium">
            ⚡ Ver Pipeline
          </a>
          <button className="flex items-center gap-2 bg-neutral-800 hover:bg-neutral-700 px-4 py-2 rounded-lg transition">
            <RefreshCcw size={18} /> Sync
          </button>
          <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center font-bold">
            ES
          </div>
        </div>
      </header>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-neutral-800 p-6 rounded-2xl border border-neutral-700 hover:border-purple-500 transition">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-neutral-400 text-sm font-medium">Total de Leads</p>
              <h3 className="text-4xl font-bold mt-2">{stats.total_leads}</h3>
            </div>
            <div className="p-3 bg-neutral-700 rounded-xl text-white">
              <Users size={24} />
            </div>
          </div>
          <div className="mt-4 text-sm text-green-400 flex items-center gap-1">
            <Zap size={14} /> Base ativa importada
          </div>
        </div>

        <div className="bg-neutral-800 p-6 rounded-2xl border border-neutral-700 hover:border-blue-500 transition">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-neutral-400 text-sm font-medium">Novos (Pipeline)</p>
              <h3 className="text-4xl font-bold mt-2">{stats.novos}</h3>
            </div>
            <div className="p-3 bg-blue-900/50 rounded-xl text-blue-400">
              <Zap size={24} />
            </div>
          </div>
          <div className="mt-4 text-sm text-neutral-400">
            Aguardando triagem
          </div>
        </div>

        <div className="bg-neutral-800 p-6 rounded-2xl border border-neutral-700 hover:border-amber-500 transition">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-neutral-400 text-sm font-medium">Leads Quentes 🔥</p>
              <h3 className="text-4xl font-bold mt-2">{stats.quentes}</h3>
            </div>
            <div className="p-3 bg-amber-900/50 rounded-xl text-amber-400">
              <Flame size={24} />
            </div>
          </div>
          <div className="mt-4 text-sm text-amber-400">
            Alta prioridade de contato
          </div>
        </div>
      </div>

      {/* Recent Leads Table */}
      <div className="bg-neutral-800 rounded-2xl border border-neutral-700 overflow-hidden">
        <div className="p-6 border-b border-neutral-700 flex justify-between items-center">
          <h2 className="text-xl font-bold">Últimos Leads Cadastrados</h2>
          <button className="text-sm text-purple-400 hover:text-purple-300">Ver Todos</button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-neutral-900/50 text-neutral-400 uppercase text-xs">
              <tr>
                <th className="px-6 py-4">Nome</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Temperatura</th>
                <th className="px-6 py-4">Score</th>
                <th className="px-6 py-4">Telefone</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-700">
              {leads.map((lead) => (
                <tr key={lead.id} className="hover:bg-neutral-700/50 transition">
                  <td className="px-6 py-4 font-medium flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-neutral-700 flex items-center justify-center text-xs">
                      {lead.full_name ? lead.full_name[0] : '?'}
                    </div>
                    {lead.full_name || 'Sem Nome'}
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-purple-900/30 text-purple-300 rounded-full text-xs font-medium border border-purple-800">
                      {lead.lead_pipeline?.stage.toUpperCase() || 'NOVO'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {lead.lead_pipeline?.temperature === 'quente' ? (
                      <span className="flex items-center gap-1 text-amber-500 font-bold text-xs"><Flame size={14} /> QUENTE</span>
                    ) : (
                      <span className="text-neutral-500 text-xs">Frio</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-neutral-400">
                    {lead.lead_pipeline?.score || 0} pts
                  </td>
                  <td className="px-6 py-4 text-neutral-400 font-mono text-sm">
                    {lead.phone_e164}
                  </td>
                </tr>
              ))}

              {leads.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-neutral-500">
                    Nenhum lead encontrado (ou erro na conexão com a API)
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
